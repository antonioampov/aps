/*
 * Барањето во задачава е да се најде на одреден ден кој слави роденден и да се испечати името и колку години ќе полни на тој ден. Прво е даден бројот на лица, потоа нивните имиња и датум 
 * на раѓање и на крај се внесува датум во форма дд/мм/гггг и треба да се испечати имињата и колку години ќе наполнат на тој датум. 
 */


import java.util.*;
import java.io.*;

public class Rodendeni2 {
	public static void main(String[] args) {
		HashMap<String, TreeMap<String, Integer>> tabela = new HashMap<>();
		Scanner in = new Scanner(System.in);
		int n = Integer.parseInt(in.nextLine());
		for (int i = 0; i < n; i++) {
			String[] line = in.nextLine().split(" ");
			String ime = line[0] + " " + line[1];
			String[] newData = line[2].split("/");
			String data = newData[0] + "/" + newData[1];
			if (tabela.containsKey(data)) {
				tabela.get(data).put(ime, Integer.parseInt(newData[2]));
			} else {
				TreeMap<String, Integer> map = new TreeMap<>();
				map.put(ime, Integer.parseInt(newData[2]));
				tabela.put(data, map);
			}
		}
		
		String[] dataVlez = in.nextLine().split("/");
		String procitaj = dataVlez[0] + "/" + dataVlez[1];
		TreeMap<String, Integer> output = tabela.get(procitaj);
		if (output != null) {
			for (Map.Entry<String, Integer> entry : output.entrySet()) {
				String imeIzlez = entry.getKey();
				int godina = Integer.parseInt(dataVlez[2]);
				int god = entry.getValue();
				int printGod = godina - god;
				System.out.println(imeIzlez + " " + printGod);
			}
		} else {
			System.out.println("Nema");
		}
	}
}