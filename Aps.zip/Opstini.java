/*
 * Барањето во задачава е да се најде просечно загадување во општината која е внесена. На влез прво има број на општини кои се внесуваат па потоа општините и загадувањето.
 * Во последниот ред е внесена општината за која треба да се испечати просечната загаденост. Решение со хеш табела.
 */

import java.util.*;
import java.io.*;
public class Opstini {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int N = Integer.parseInt(reader.readLine());
        HashMap<String, Municipal> merki = new HashMap<>();
        for(int i = 0; i < N; i++) {
        	String[] parts = reader.readLine().split(" ");
        	if(merki.containsKey(parts[0])) {
        		Municipal m = merki.get(parts[0]);
        		m.dodadiMerenje(Double.parseDouble(parts[1]));
        	}
        	else {
        		merki.put(parts[0], new Municipal(parts[0], Double.parseDouble(parts[1])));
        	}
        	
        }
        String o = reader.readLine();
        Municipal m = merki.get(o);
        System.out.println(m.toString());
    }
}

class Municipal {
    private String ime;
    private double zagaduvanja;
    private List<Double> merenja;
    
    Municipal(String ime, double zagaduvanja){
    	this.ime = ime;
    	this.zagaduvanja = zagaduvanja;
    	this.merenja = new ArrayList<>();
    	merenja.add(zagaduvanja);
    }
    private double najdiProsecnoZagaduvanje() {
    	double vkupno = 0;
    	for(double d : merenja) {
    		vkupno += d;
    	}
    	return vkupno / merenja.size();
    }
    void dodadiMerenje(double merenje) {
    	merenja.add(merenje);
    }
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%.2f", najdiProsecnoZagaduvanje());
	}
	public String getIme() {
		return ime;
	}
	public double getZagaduvanje() {
		return zagaduvanja;
	}
    
    
}