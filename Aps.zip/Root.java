/*
 * 
 * 2
root/a/ xy.txt (abv)
root/a/b/ cx.txt (xyz)
3
add root/a/c/ xy2.txt (abv)
delete root/a/c xy.txt (abv)
find root/a/ xy.txt (abv)
abv
Aj vaka ke probam da ja objasnam nekako. Prvata brojka kazuva kolku datoteki ima i koja im e patekata root/a/b e patekata kaj st ose naoga fajlot cx.txt a (xyz) ako dobro pamtam bese 
sodrzinata vo cx.txt. Sodrzinata vo primerov xyz treba da bide klucot.
Vtorata brojka (3) go oznacuva brojot na komandi. Na raspolaganje bea add, delete i find. Add dodava fajl vo posocenata pateka, delete go brise fajlot vo posocenata datoteka 
(dokolku postoi istiot), find vraka true ili false vo zavisnsot od toa dali pod odredeniot kluc ima fajl so dadenoto ime vo posocenata pateka.
Na kraj abv treba da ispecati sto se cuva klucot (vo slucajov abv), vo slucajov ke ispecati root/a/c/ xy2.txt bidejki xy.txt koj go zadavam vo vtorata linija podocna se brise
 so delete opcijata. Dokolku go imavme istiot primer samo bez delete abv ke ni vratese root/a/ xy.txt root/a/c/ xy2.txt
 */

import java.util.*;

public class Root {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = Integer.parseInt(in.nextLine());
		HashMap<String, String> map = new HashMap<>();
		for(int i = 0; i < n; i++) {
			String[] line = in.nextLine().split(" ");
			String kluc = line[2];
			if(map.containsKey(kluc)) {
				String vrednost = map.get(kluc);
				vrednost += " " + line[0]+line[1];
			}
			else {
				String vrednost = line[0]+line[1];
				map.put(kluc, vrednost);
			}
		}
		//System.out.println(map);
		
		int m = Integer.parseInt(in.nextLine());
		boolean flag = false;
		for(int i = 0; i < m; i++) {
			String[] line = in.nextLine().split(" ");
			String kluc = line[3];
			if(line[0].equals("add")) {
				String temp = map.get(kluc);
				temp += " " + line[1]+line[2];
				map.put(line[3], temp);
				
			}
			else if(line[0].equals("delete")) {
				String[] deli = map.get(kluc).split(" ");
				String pom = "";
				for(int j = 0; j < deli.length; j++) {
					if(!deli[j].equals(line[1]+line[2])) {
						pom += deli[j] + " ";
					}
				}
				if(pom.equals(""))
					map.remove(kluc);
				else
					map.put(kluc, pom);
			}
			else if(line[0].equals("find")) {
				String[] deli = map.get(kluc).split(" ");
				for(int s = 0; s < deli.length;s++) {
					if(deli[s].equals(line[1]+line[2])) {
						flag = true;
						break;
					}
				}
			}
		}
		System.out.println(map);
		String najdi = in.nextLine();
		najdi = "("+najdi+")";
		String izlez = map.get(najdi);
		System.out.println(flag);
		System.out.println(izlez);
	}

}

